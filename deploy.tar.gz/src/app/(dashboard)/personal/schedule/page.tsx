// personal/schedule/page.tsx
// Placeholder stub — real implementation not yet built.
// Kept to avoid 404 on sidebar navigation.

import { Placeholder } from '@/components/layout/Placeholder'

export default function Page() {
  return (
    <Placeholder
      title="My Schedule"
      description="Jadwal harian/mingguan kamu. Coming soon."
    />
  )
}
